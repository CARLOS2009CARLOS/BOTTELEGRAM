<?php
date_default_timezone_set("Asia/Baghdad");
error_reporting(0);
if (!file_exists("ID")) {
$g = readline("admin id : ");
file_put_contents("ID", $g);
}
if (!file_exists("ch")) {
file_put_contents("ch", "Bello");
}
if (!file_exists("token")) {
$g = readline("token : ");
file_put_contents("token", $g);
}
if (!file_exists("info.json")) {
file_put_contents("info.json", "");
}
$info = json_decode(file_get_contents('info.json'),true);
$info["number1"] = "No number";
$info = json_decode(file_get_contents('info.json'),true);
$info["num1"] = "off";
file_put_contents('info.json', json_encode($info));
echo "Running Bot...\n";
shell_exec("pm2 start bot.php");
echo "Account Bot...\n";
shell_exec("pm2 start t.php");
echo "Done\n\n\n\n";