<?php
date_default_timezone_set("Asia/Baghdad");
error_reporting(0);
function bot($method, $datas = []) {
$token = file_get_contents("token");
$url = "https://api.telegram.org/bot$token/" . $method;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$res = curl_exec($ch);
curl_close($ch);
return json_decode($res, true);
}
function getupdates($up_id) {
$get = bot('getupdates', ['offset' => $up_id]);
return end($get['result']);
}
$botuser = "@" . bot('getme', ['bot']) ["result"]["username"];
file_put_contents("_ad.txt", $botuser);
function stats($nn) {
	$st = "";
	$x = shell_exec("pm2 show $nn");
	if (preg_match("/online/", $x)) {
		$st = "run";
	}
	else {
		$st = "stop";
	}
	return $st;
}
function states($g) {
$st = "";
$x = shell_exec("pm2 show $g");
if(preg_match("/online/", $x)) {
$st = "run";
}else{
$st = "stop";
}
return $st;
}
function countUsers($u = "2", $t = "2") {
if ($t == "2") {
$users = explode("\n", file_get_contents("users"));
$list = "";
$i = 1;
foreach ($users as $user) {
if ($user != "") {
$list = $list . "\n$i  • ❲ @$user";
$i++;
}
}
if ($list == "") {
return "There is no username in the list";
}
else {
return $list;
}
}
if ($t == "1") {
$users = explode("\n", $u);
$list = "";
$i = 1;
foreach ($users as $user) {
if ($user != "") {
$list = $list . "\n$i  • ❲ @$user";
$i++;
}
}
if ($list == "") {
return "There is no username in the list";
}
else {
return $list;
}
}
}
 $last_up = $last_up;
function ph($ph, $group) {
	global $last_up;
	$step = 0;
		bot('sendMessage', ['chat_id' => $group, 'text' => "- Signing in ... "]);
	if (!file_exists('madeline.php')) {
		copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
	}
	define('MADELINE_BRANCH', 'deprecated');
	include 'madeline.php';
	unlink("a.madeline");
	unlink("a.madeline.lock");
	$settings['app_info']['api_id'] = 579315;
	$settings['app_info']['api_hash'] = '4ace69ed2f78cec268dc7483fd3d3424';
	$MadelineProto = new \danog\MadelineProto\API('a.madeline', $settings);
	try {
		$vv = $MadelineProto->phone_login($ph);
$info = json_decode(file_get_contents('info.json'),true);
$info["number1"] = "$ph";
file_put_contents('info.json', json_encode($info));
		echo json_encode($vv);
		bot('sendMessage', ['chat_id' => $group, 'text' =>" - Send code :"]);
		$step = 1;
	}
	catch(Exception $e) {
		bot('sendMessage', ['chat_id' => $group, 'text' => "- is the checker number ❲ Band ❳ ،\nI can't Login to Account"]);
		return false;
shell_exec("php step.php");	}
	
	while (1) {
$get_up = getupdates($last_up + 1);
$last_up = $get_up['update_id'];
if ($get_up) {
	$message = $get_up['message'];
	$userID = $message['from']['id'];
	$chat_id = $message['chat']['id'];
	$text = $message['text'];
	if ($chat_id == $group) {
	if ($text) {
	if ($step == 2) {
try {
$authorization = $MadelineProto->complete_2fa_login($text);
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- is the checker number ❲ Band ❳ ،\n• Done Login The Account ،!\n You can run the checker"]);
break;
}
catch(Exception $e) {
echo $e->getMessage();
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "Error" . $e->getMessage() ]);
break;
}
$authorization = $MadelineProto->complete_2fa_login($text);
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- is the checker number ❲ Band ❳ ،\n• Done Login The Account ،!\n You can run the checker"]);
break;
}
if ($step == 1) {
try {
$authorization = $MadelineProto->complete_phone_login($text);
if ($authorization['_'] === 'account.password') {
bot('sendmessage', ['chat_id' => $chat_id, 'text' => "- is the checker number ❲ Band ❳ ،\n- Send Account 2 password ،!\n- Example : ❲ MOHAMMED ❳ ٫،!", ]);
$step = 2;
}
else {
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "- Congratulations you now can used me now.
"]);
break;
}
}
catch(Exception $e) {
echo $e->getMessage();
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "Error" . $e->getMessage() ]);
break;
}
}
}
}
}
sleep(1);
}
}
$step = "";
function run($update) {
global $step;
$nn = bot('getme', ['bot']) ["result"]["username"];
$message = $update['message'];
$userID = $message['from']['id'];
$chat_id = $message['chat']['id'];
$text = $message['text'];

$group = file_get_contents("ID");
$g = file_get_contents($url);
$js = json_decode($g);
$da = $js->date;
$time = $js->time;
$day = $js->day;
$month = $js->month;

if ($chat_id == $group) {
if ($text) {
$date = $update['callback_query']['data'];
$cq = $update['callback_query'];
$data = $cq['data'];
$message_id = $cq['message']['message_id'];
$chat_id2 = $cq['message']['chat']['id'];

if ($text == "/start") {
bot('sendMessage', ['chat_id' => $chat_id, 'text' => "

- Hi sir. 

- Im here to taken banned users when back for service.
 
- You can use me for a one month.

- You can put a just 1 number.

- Thank you for reading.

- Supported by : @cDDDD.
", 'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" =>"Add Users"],["text" =>"Delet User"]],
[["text" =>"Run"],["text" =>"Stop"]],
[["text" =>"Delet Users"],["text" =>"Users List"]],
[["text" =>"Remove Number"],["text" =>"Put Number"]]], ]) ]);
}
if(file_exists('mode')){
$mode = file_get_contents('mode');
$users = explode("\n", file_get_contents('users'));
if(preg_match("/@+/", $text)){
if($mode == 'pinall'){
$user = explode("@", $text) [1];
if (!in_array($user, $users)) {
file_put_contents("users", "\n" . $user, FILE_APPEND);
bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"@$user : Done Pin All.",]);
shell_exec("pm2 start t.php");
} else {
bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"@$user : Already Exists.",]);
}
unlink('mode');
} elseif($mode == 'Unpin'){
echo 'unpin';
$user = explode("@", $text) [1];
$data = str_replace("\n" . $user, "", file_get_contents("users"));
file_put_contents("users", $data);
file_put_contents("users",preg_replace('~[\r\n]+~',"\n",trim(file_get_contents("users"))));
bot('sendMessage', ['chat_id' => $chat_id,  'text' => "- Done deleted user from List : @$user",]);
unlink('mode');
} elseif($mode == 'addL'){
echo $mode;
$ex = explode("\n", $text);
$userT = "";
$userN = "";
foreach ($ex as $u) {
$users = explode("\n", file_get_contents("users"));
 $user = explode("@", $u) [1];
if (!in_array($user, $users)) {
$userT = $userT . "\n" . $user;
}
else {
$userN = $userN . "\n" . $user;
}
}
file_put_contents("users", $userT, FILE_APPEND);
bot('sendMessage', ['chat_id' => $chat_id,  'text' => "- Done added users to List :\n" . countUsers($userT, "1") ,]);
unlink('mode');
}
}}
if($text == "Delet Users"){
 bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"- Done deleted all users on list.",]);
file_put_contents("users", "");
}
if($text == "Users List"){
if(file_exists("users")){
$users = explode("\n", file_get_contents("users"));
$list = "";
$i = 1;
foreach ($users as $user) {
if ($user != "") {
$list = $list . "\n$i  • ❲ @$user";
$i++;}}
bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"- This all users in list : \n".$list,]);
$list = "";
}else{
bot('sendMessage', ['chat_id' => $chat_id, 'text'=>" No users in list Band",]);
}}
if ($step == "ph") {
ph($text, $group);
$step = "";
system('screen -dmS MD php step.php');
}
if($text == "Put Number"){
bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"- Send number to add for me :

مثال : +96444444447.
", ]);
shell_exec("pm2 stop t.php");
unlink("a.madeline");
unlink("a.madeline.lock");
$step = "ph";
}
if($text == "Remove Number"){
 bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"Done deleted number from me !",]);
shell_exec("pm2 stop t.php");
unlink("a.madeline");
unlink("a.madeline.lock");
$info = json_decode(file_get_contents('info.json'),true);
$info["number1"] = "No number";
file_put_contents('info.json', json_encode($info));
}
if($text == "Stop"){
bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"
- Done stopped checker.

- Stopped date : ( $da | $time ).

- Checker stopped running.",]);
shell_exec("pm2 stop t.php");
$info = json_decode(file_get_contents('info.json'),true);
$info["num1"] = "off";
file_put_contents('info.json', json_encode($info));
}
if($text == "Run"){
 bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"
- Im running now.

- Date start :  ( $da | $time )

- Checking has starting on list banned users.

- Supported by : @cDDDD.
",]);
shell_exec("pm2 stop t.php");
shell_exec("pm2 start t.php");
$info = json_decode(file_get_contents('info.json'),true);
$info["num1"] = "on";
file_put_contents('info.json', json_encode($info));
}
if($text == "Add Users"){
 bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"- send banned users list :",]);
file_put_contents('mode', 'addL');
}
if($text == "Delet User"){
bot('sendMessage', ['chat_id' => $chat_id, 'text'=>"- Send the user you want to delete !"]);
file_put_contents('mode', 'Unpin');
}}}
$lastupdid = $update['result'][0]['update_id'] + 1; 
}
while (true) {
global $last_up;
$get_up = getupdates($last_up + 1);
$last_up = $get_up['update_id'];
if ($get_up) {
run($get_up);
sleep(1);
}
}
?>